const FLAG = "flag{sample}"

module.exports = {FLAG}
